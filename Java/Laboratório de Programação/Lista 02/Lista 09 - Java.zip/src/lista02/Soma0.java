package lista02;

public class Soma0{
    
    public static void main (String[] args){
        int a = 10;
        int b = 10;
        int resultado = a + b;
        
        System.out.println("A soma de " + a + " com " + b + " equivale a: " + resultado);
        
        
    }
    

}
